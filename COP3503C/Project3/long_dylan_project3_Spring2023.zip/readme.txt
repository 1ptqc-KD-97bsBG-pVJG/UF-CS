Name: Dylan Long
Section: 29075
UFL email: dylan.long@ufl.edu
System: MacOS
Compiler: g++
SFML version: 2.5.1_2
IDE: cLion
Other notes: M1 Mac