#pragma once
#include <SFML/Graphics.hpp>
#include <vector>
using namespace std;
using namespace sf;

int displayLeaderboard(int windowWidth, int windowHeight);